import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';

class ProfilePage extends StatefulWidget {
  @override
  _ProfilePageState createState() => _ProfilePageState();
}

class _ProfilePageState extends State<ProfilePage> {
  late User? _user;
  late Map<String, dynamic>? _userData;

  @override
  void initState() {
    super.initState();
    _getUserData();
  }

  Future<void> _getUserData() async {
    User? user = FirebaseAuth.instance.currentUser;
    if (user != null) {
      DocumentSnapshot userSnapshot =
          await FirebaseFirestore.instance.collection('users').doc(user.uid).get();

      setState(() {
        _user = user;
        _userData = userSnapshot.data() as Map<String, dynamic>?;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Profile'),
        backgroundColor: Colors.blue, // Customize the app bar color
      ),
      body: _user != null
          ? Container(
              padding: EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  CircleAvatar(
                    radius: 60,
                    backgroundColor: Colors.blue,
                    child: Icon(
                      Icons.person,
                      size: 80,
                      color: Colors.white,
                    ),
                  ),
                  SizedBox(height: 20),
                  Text(
                    _userData?['username'] ?? 'N/A',
                    style: TextStyle(fontSize: 24, fontWeight: FontWeight.bold),
                  ),
                  Text(
                    _user?.email ?? 'N/A',
                    style: TextStyle(fontSize: 16, color: Colors.grey),
                  ),
                  Divider(color: Colors.grey, height: 30),
                  Text(
                    'Contact Information',
                    style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                  ),
                  ListTile(
                    leading: Icon(Icons.phone),
                    title: Text('Phone: ${_userData?['phone'] ?? 'N/A'}'),
                  ),
                  ListTile(
                    leading: Icon(Icons.location_on),
                    title: Text('Country: ${_userData?['country'] ?? 'N/A'}'),
                  ),
                  ListTile(
                    leading: Icon(Icons.location_city),
                    title: Text('City: ${_userData?['city'] ?? 'N/A'}'),
                  ),
                  ListTile(
                    leading: Icon(Icons.map),
                    title: Text('Location: ${_userData?['location'] ?? 'N/A'}'),
                  ),
                ],
              ),
            )
          : Center(
              child: CircularProgressIndicator(),
            ),
    );
  }
}