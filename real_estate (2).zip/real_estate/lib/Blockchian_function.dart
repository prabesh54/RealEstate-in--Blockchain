import 'package:flutter/material.dart';
import 'package:http/http.dart';
import 'package:web3dart/web3dart.dart';

class PropertyRegistryIntegration {
  final Web3Client client;
  final EthereumAddress contractAddress;

  PropertyRegistryIntegration(this.client, this.contractAddress);

  Future<String> registerProperty(
      String propertyName, String ownerName, String country, String contactNumber) async {
    DeployedContract contract = await loadContract();
    final ethFunction = contract.function('registerProperty');

    final credentials = await client.credentialsFromPrivateKey('a0f938e3a25cbab67c31f41e8553a11d6c53cb2ddd5cda19638b4b2a49a2e597');

    // Send a transaction to the Ethereum blockchain
    final result = await client.sendTransaction(
      credentials,
      Transaction.callContract(
        contract: contract,
        function: ethFunction,
        parameters: [propertyName, ownerName, country, contactNumber],
      ),
      chainId: 11155111, // testnet
    );

    // Return the transaction hash
    return result;
  }

  Future<List<String>> getPropertyDetails(String hashCode) async {
    DeployedContract contract = await loadContract();
    final ethFunction = contract.function('getPropertyDetails');

    // Call the getPropertyDetails function on the contract
    final result = await client.call(
      contract: contract,
      function: ethFunction,
      params: [EthereumAddress.fromHex(hashCode)],
    );

    // Convert the result to a list of strings
    List<String> propertyDetails = result.map((value) => value.toString()).toList();

    return propertyDetails;
  }

  Future<DeployedContract> loadContract() async {
    // Load ABI from the asset file
    String abi = 'assets/property_registry_abi.json';

    // Creating DeployedContract instance
    return DeployedContract(
      ContractAbi.fromJson(abi, 'PropertyRegistry'),
      contractAddress,
    );
  }
}



class MyContract extends StatelessWidget {
  final client = Web3Client('https://sepolia.infura.io/v3/3bfe33f1eeec4d7db8cc588abe9672ea', Client());
  final contractAddress = EthereumAddress.fromHex('0x9D7f74d0C41E726EC95884E0e97Fa6129e3b5E99');

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: MyHomePage(
        propertyRegistryIntegration: PropertyRegistryIntegration(client, contractAddress),
      ),
    );
  }
}

class MyHomePage extends StatelessWidget {
  final PropertyRegistryIntegration propertyRegistryIntegration;

  MyHomePage({required this.propertyRegistryIntegration});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Property Registry Integration'),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            ElevatedButton(
              onPressed: () async {
                String transactionHash = await propertyRegistryIntegration.registerProperty(
                  'Property Name',
                  'Owner Name',
                  'Country',
                  'Contact Number',
                );
                print('Transaction Hash: $transactionHash');
              },
              child: Text('Register Property'),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: () async {
                List<String> propertyDetails =
                    await propertyRegistryIntegration.getPropertyDetails('HASH_CODE_TO_RETRIEVE_DETAILS');
                print('Property Details: $propertyDetails');
              },
              child: Text('Get Property Details'),
            ),
          ],
        ),
      ),
    );
  }
}