// PropertyListPage.dart

import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:flutter/material.dart';

class PropertyListPage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Property List'),
      ),
      body: PropertyList(),
    );
  }
}

class PropertyList extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return StreamBuilder<QuerySnapshot>(
      stream: FirebaseFirestore.instance.collection('properties').snapshots(),
      builder: (context, snapshot) {
        if (snapshot.connectionState == ConnectionState.waiting) {
          return Center(child: CircularProgressIndicator());
        }

        if (snapshot.hasError) {
          return Center(child: Text('Error: ${snapshot.error}'));
        }

        if (!snapshot.hasData || snapshot.data!.docs.isEmpty) {
          return Center(child: Text('No properties found.'));
        }

        return ListView.builder(
          itemCount: snapshot.data!.docs.length,
          itemBuilder: (context, index) {
            var property = snapshot.data!.docs[index];
            return PropertyBlock(
              ownerName: property['ownerName'],
              country: property['country'],
              contactNumber: property['contactNumber'],
              propertyNumber: property['propertyNumber'],
              // Add your image URL field
            );
          },
        );
      },
    );
  }
}

class PropertyBlock extends StatelessWidget {
  final String ownerName;
  final String country;
  final String contactNumber;
  final String propertyNumber;

  PropertyBlock({
    required this.ownerName,
    required this.country,
    required this.contactNumber,
    required this.propertyNumber,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      margin: EdgeInsets.all(8.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('Owner Name: $ownerName'),
                Text('Country: $country'),
                Text('Contact Number: $contactNumber'),
                Text('Property Number: $propertyNumber'),
              ],
            ),
          ),
        ],
      ),
    );
  }
}
