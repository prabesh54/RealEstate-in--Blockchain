// RealEstateDashboard.dart
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter/material.dart';
import 'package:real_estate/AddProperty.dart';
import 'package:real_estate/HomePage.dart';
import 'package:real_estate/Profilepage.dart';
import 'package:real_estate/newdashboard.dart';

class Property {
  final String imageUrl;
  final String title;
  final String location;
  final HouseType houseType;

  Property({
    required this.imageUrl,
    required this.title,
    required this.location,
    required this.houseType,
  });
}

enum HouseType {
  Apartment,
  House,
  Condo,
  Villa,
  Other,
}

class RealEstateDashboard extends StatelessWidget {
  String userName = "John Doe";
  String ownerName = "Oner Name";
  String country = "Country";
  String contactNumber = "1234567890";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Property Dashboard'),
        actions: [
          IconButton(
            icon: Icon(Icons.exit_to_app),
            onPressed: () async {
              await FirebaseAuth.instance.signOut();
              Navigator.pushReplacement(
                context,
                MaterialPageRoute(builder: (context) => HomePage()),
              );
            },
          ),
        ],
      ),
      body: PropertyList(),
      bottomNavigationBar: BottomAppBar(
        color: Colors.blue,
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              Row(
                children: [
                  IconButton(
                    icon: Icon(Icons.notifications),
                    onPressed: () {
                      // Add your notification logic here
                    },
                  ),
                  IconButton(
                    icon: Icon(Icons.person),
                    onPressed: () async {
                      User? user = FirebaseAuth.instance.currentUser;
                      if (user != null) {
                        Navigator.push(
                          context,
                          MaterialPageRoute(
                            builder: (context) => ProfilePage()
                          ),
                        );
                      }
                    },
                  ),
                ],
              ),
              ElevatedButton(
                onPressed: () {
                  Navigator.push(
                    context,
                    MaterialPageRoute(builder: (context) => AddPropertyPage()),
                  );
                },
                child: Text('Property Registration'),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class PropertyCard extends StatelessWidget {
  final String title;
  final String location;
  final HouseType houseType;

  PropertyCard({
    required this.title,
    required this.location,
    required this.houseType,
  });

  @override
  Widget build(BuildContext context) {
    IconData iconData = _getIconDataFromHouseType(houseType);

    return Card(
      elevation: 5.0,
      margin: EdgeInsets.symmetric(vertical: 10.0),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Padding(
            padding: const EdgeInsets.all(8.0),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text(
                  title,
                  style: TextStyle(fontSize: 18.0, fontWeight: FontWeight.bold),
                ),
                SizedBox(height: 8.0),
                Row(
                  children: [
                    Icon(iconData),
                    SizedBox(width: 8.0),
                    Text(location),
                  ],
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }

  IconData _getIconDataFromHouseType(HouseType houseType) {
    switch (houseType) {
      case HouseType.Apartment:
        return Icons.apartment;
      case HouseType.House:
        return Icons.home;
      case HouseType.Condo:
        return Icons.account_balance;
      case HouseType.Villa:
        return Icons.house;
      case HouseType.Other:
        return Icons.business;
    }
  }
}
